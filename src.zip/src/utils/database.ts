import { Database } from '../structures/Database';

const db: Database = new Database();

export default db;